function gohome(){
    document.getElementById("appwindow").src = "./myhome.html";
    
}