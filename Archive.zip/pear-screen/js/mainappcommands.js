function openauthor(){
    document.getElementById("appwindow").src = "./author/index.html";
    
}